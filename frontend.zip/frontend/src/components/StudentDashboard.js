import React from "react";

const StudentDashboard = () => {
  return <div>Welcome to Student Dashboard</div>;
};

export default StudentDashboard;
