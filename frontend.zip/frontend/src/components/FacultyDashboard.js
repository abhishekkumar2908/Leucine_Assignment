// src/components/FacultyDashboard.js
import React from "react";

const FacultyDashboard = () => {
  return <div>Welcome to Faculty Dashboard</div>;
};

export default FacultyDashboard;
